from langchain_chroma import Chroma
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

from .config import (
    CHROMA_DIR,
    CHUNK_OVERLAP,
    CHUNK_SIZE,
    COLLECTION_GUIDES,
    GUIDE_PDF,
)
from .embeddings import get_embeddings


def ingest():
    pages = PyPDFLoader(str(GUIDE_PDF)).load()
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP
    )
    chunks = splitter.split_documents(pages)
    ids = [f"guide-{i}" for i in range(len(chunks))]
    for d in chunks:
        d.metadata["source"] = "guides"

    store = Chroma(
        collection_name=COLLECTION_GUIDES,
        embedding_function=get_embeddings(),
        persist_directory=str(CHROMA_DIR),
    )
    store.delete(ids=ids)
    store.add_documents(chunks, ids=ids)
    print(f"Ingested {len(chunks)} guide chunks.")


if __name__ == "__main__":
    ingest()
