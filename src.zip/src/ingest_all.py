from . import ingest_faq, ingest_guides, ingest_plans, ingest_tickets

if __name__ == "__main__":
    ingest_faq.ingest()
    ingest_tickets.ingest()
    ingest_guides.ingest()
    ingest_plans.ingest()
