from langchain_chroma import Chroma
from langchain_core.runnables import RunnableLambda, RunnableParallel

from .config import (
    CHROMA_DIR,
    COLLECTION_FAQ,
    COLLECTION_GUIDES,
    COLLECTION_PLANS,
    COLLECTION_TICKETS,
    TOP_K,
)
from .embeddings import get_embeddings

SOURCE_LABELS = {
    COLLECTION_FAQ: "FAQ",
    COLLECTION_TICKETS: "TICKETS",
    COLLECTION_GUIDES: "GUIDES",
    COLLECTION_PLANS: "PLANS",
}


def _store(name: str) -> Chroma:
    return Chroma(
        collection_name=name,
        embedding_function=get_embeddings(),
        persist_directory=str(CHROMA_DIR),
    )


def _retriever(name: str):
    return _store(name).as_retriever(search_kwargs={"k": TOP_K})


def build_merged_retriever():
    parallel = RunnableParallel(
        faq=_retriever(COLLECTION_FAQ),
        tickets=_retriever(COLLECTION_TICKETS),
        guides=_retriever(COLLECTION_GUIDES),
        plans=_retriever(COLLECTION_PLANS),
    )
    return parallel | RunnableLambda(_format_context)


def _format_context(results: dict) -> str:
    blocks = []
    for collection, docs in results.items():
        label = SOURCE_LABELS.get(collection, collection.upper())
        for d in docs:
            blocks.append(f"[{label}] {d.page_content}")
    return "\n\n".join(blocks) if blocks else "(no relevant context found)"
