import json

from langchain_chroma import Chroma
from langchain_core.documents import Document

from .config import CHROMA_DIR, COLLECTION_PLANS, PLANS_JSON
from .embeddings import get_embeddings


def _format_price(plan: dict, currency: str) -> str:
    """Return a readable price line for either monthly plans or add-ons."""
    if "monthly_price" in plan:
        line = f"Price: {currency} {plan['monthly_price']:.2f}/month"
        if plan.get("price_per_line") is not None:
            line += f" (about {currency} {plan['price_per_line']:.2f} per line)"
        if plan.get("lines_included"):
            line += f", {plan['lines_included']} lines included"
        return line
    if "price" in plan:
        unit = plan.get("price_unit", "per month")
        return f"Price: {currency} {plan['price']:.2f} {unit}"
    return "Price: not specified"


def _format_data(plan: dict) -> str:
    if plan.get("data_unlimited"):
        return "Data: Unlimited"
    data = plan.get("data_gb")
    if data is None:
        return ""
    if isinstance(data, (int, float)):
        return f"Data: {data} GB"
    return f"Data: {data}"


def _plan_to_text(plan: dict, currency: str) -> str:
    """Turn one plan dict into a self-contained, retrievable document."""
    lines = [
        f"Plan: {plan['name']} ({plan.get('type', 'plan')})",
        _format_price(plan, currency),
    ]

    data_line = _format_data(plan)
    if data_line:
        lines.append(data_line)

    if plan.get("talk_minutes") is not None:
        lines.append(f"Talk: {plan['talk_minutes']}")
    if plan.get("texts") is not None:
        lines.append(f"Texts: {plan['texts']}")
    if plan.get("hotspot_gb"):
        lines.append(f"Mobile hotspot: {plan['hotspot_gb']} GB")
    if plan.get("network"):
        lines.append(f"Network: {plan['network']}")
    if plan.get("coverage"):
        lines.append(f"Coverage: {plan['coverage']}")
    if plan.get("contract"):
        lines.append(f"Contract: {plan['contract']}")
    if plan.get("eligibility"):
        lines.append(f"Eligibility: {plan['eligibility']}")
    if plan.get("intro_offer"):
        lines.append(f"Intro offer: {plan['intro_offer']}")
    if plan.get("features"):
        lines.append("Features: " + "; ".join(plan["features"]))
    if plan.get("best_for"):
        lines.append(f"Best for: {plan['best_for']}")

    return "\n".join(lines)


def ingest():
    catalog = json.loads(PLANS_JSON.read_text(encoding="utf-8"))
    currency = catalog.get("currency", "USD")
    plans = catalog.get("plans", [])

    docs = []
    ids = []
    for plan in plans:
        docs.append(
            Document(
                page_content=_plan_to_text(plan, currency),
                metadata={
                    "source": "plans",
                    "id": plan["id"],
                    "name": plan["name"],
                    "category": plan.get("category", "plan"),
                },
            )
        )
        ids.append(f"plan-{plan['id']}")

    store = Chroma(
        collection_name=COLLECTION_PLANS,
        embedding_function=get_embeddings(),
        persist_directory=str(CHROMA_DIR),
    )
    store.delete(ids=ids)
    store.add_documents(docs, ids=ids)
    print(f"Ingested {len(docs)} plans.")


if __name__ == "__main__":
    ingest()
