import pandas as pd
from langchain_chroma import Chroma
from langchain_core.documents import Document

from .config import CHROMA_DIR, COLLECTION_FAQ, FAQ_CSV
from .embeddings import get_embeddings


def ingest():
    df = pd.read_csv(FAQ_CSV)
    docs = [
        Document(
            page_content=f"Q: {row.question}\nA: {row.answer}",
            metadata={"source": "faq", "id": str(row.id), "category": row.category},
        )
        for row in df.itertuples(index=False)
    ]
    ids = [f"faq-{d.metadata['id']}" for d in docs]
    store = Chroma(
        collection_name=COLLECTION_FAQ,
        embedding_function=get_embeddings(),
        persist_directory=str(CHROMA_DIR),
    )
    store.delete(ids=ids)
    store.add_documents(docs, ids=ids)
    print(f"Ingested {len(docs)} FAQ entries.")


if __name__ == "__main__":
    ingest()
