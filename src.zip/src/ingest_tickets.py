import sqlite3

from langchain_chroma import Chroma
from langchain_core.documents import Document

from .config import CHROMA_DIR, COLLECTION_TICKETS, TICKETS_DB
from .embeddings import get_embeddings


def ingest():
    conn = sqlite3.connect(TICKETS_DB)
    rows = conn.execute(
        "SELECT ticket_id, category, issue_type, description, resolution "
        "FROM tickets WHERE status = 'resolved'"
    ).fetchall()
    conn.close()

    docs = []
    ids = []
    for ticket_id, category, issue_type, description, resolution in rows:
        content = (
            f"Issue: {issue_type}\n"
            f"Description: {description}\n"
            f"Resolution: {resolution}"
        )
        docs.append(
            Document(
                page_content=content,
                metadata={
                    "source": "tickets",
                    "ticket_id": ticket_id,
                    "category": category,
                    "issue_type": issue_type,
                },
            )
        )
        ids.append(f"ticket-{ticket_id}")

    store = Chroma(
        collection_name=COLLECTION_TICKETS,
        embedding_function=get_embeddings(),
        persist_directory=str(CHROMA_DIR),
    )
    store.delete(ids=ids)
    store.add_documents(docs, ids=ids)
    print(f"Ingested {len(docs)} resolved tickets.")


if __name__ == "__main__":
    ingest()
