from .chain import build_chain


def main():
    chain = build_chain()
    print("Telecom Support Chatbot — type 'quit' to exit.\n")
    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not question:
            continue
        if question.lower() == "quit":
            break
        print("Bot: ", end="", flush=True)
        for token in chain.stream(question):
            print(token, end="", flush=True)
        print("\n")


if __name__ == "__main__":
    main()
